# GRAFCET Editor Documentation

Welcome to the GRAFCET Editor documentation! This directory contains guides and references to help you get started and master the editor.

## 📚 Documentation Index

### Getting Started
- **[Quick Start Guide](quick-start.md)** - Get up and running quickly
- **[User Interface Overview](ui-overview.md)** - Learn about the editor interface

### Core Concepts
- **[Action Qualifiers Guide](action-qualifiers.md)** ⭐ **NEW** - Complete guide to SFC action types (N, S, R, D, L, P, etc.)
- **[GRAFSCRIPT Language](grafscript/GRAFSCRIPT.md)** - Programming language for GRAFCET diagrams
- **[GEMMA Guide](gemma-guide.md)** - Guide d'Etude des Modes de Marches et d'Arrêts

### Advanced Topics
- **[Project Structure](project-structure.md)** - Understanding project organization
- **[Keyboard Shortcuts](shortcuts.md)** - Speed up your workflow
- **[Best Practices](best-practices.md)** - Tips for creating maintainable diagrams

## 🎯 Quick Links

### For New Users
1. Start with the [Quick Start Guide](quick-start.md)
2. Learn about [Action Qualifiers](action-qualifiers.md) to understand how actions work
3. Explore the [GRAFSCRIPT Language](grafscript/GRAFSCRIPT.md) for programming

### For Experienced Users
- [Advanced Patterns](advanced-patterns.md)
- [Integration Guide](integration.md)
- [API Reference](api-reference.md)

## 🆕 What's New

### Latest Updates
- **Action Qualifiers**: New structured editor with support for all IEC 61131-3 SFC qualifiers
- **Visual Improvements**: Action blocks now display qualifiers and durations
- **Enhanced UX**: Modal-based action editing with autocomplete

## 📖 Additional Resources

- [IEC 61131-3 Standard](https://www.iec.ch/) - Official SFC/GRAFCET standard
- [GRAFCET Tutorial](https://grafcet-tutorial.com/) - External learning resources
- [Community Forum](https://forum.grafcet-editor.com/) - Get help from the community

## 🤝 Contributing

Found an error or want to improve the documentation? Contributions are welcome!

---

**Need help?** Check the relevant guide above or contact support.
